This zip archive contains data files from Cricsheet in JSON format. This
archive contains 1315 India matches of all types. A further 14 matches have
been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/india_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-06-02 - international - T20 - female - 1496550 - India vs England
2026-05-30 - international - T20 - female - 1496549 - England vs India
2026-05-28 - international - T20 - female - 1496548 - India vs England
2026-04-27 - international - T20 - female - 1527257 - South Africa vs India
2026-04-25 - international - T20 - female - 1527256 - India vs South Africa
2026-04-22 - international - T20 - female - 1527255 - India vs South Africa
2026-04-19 - international - T20 - female - 1527254 - India vs South Africa
2026-04-17 - international - T20 - female - 1527253 - India vs South Africa
2026-03-08 - international - T20 - male - 1512773 - India vs New Zealand
2026-03-06 - international - Test - female - 1478918 - India vs Australia
2026-03-05 - international - T20 - male - 1512772 - India vs England
2026-03-01 - international - T20 - male - 1512770 - West Indies vs India
2026-03-01 - international - ODI - female - 1478917 - Australia vs India
2026-02-27 - international - ODI - female - 1478916 - India vs Australia
2026-02-26 - international - T20 - male - 1512766 - India vs Zimbabwe
2026-02-24 - international - ODI - female - 1478915 - India vs Australia
2026-02-22 - international - T20 - male - 1512761 - South Africa vs India
2026-02-21 - international - T20 - female - 1478914 - India vs Australia
2026-02-19 - international - T20 - female - 1478913 - Australia vs India
2026-02-18 - international - T20 - male - 1512754 - India vs Netherlands
2026-02-15 - international - T20 - male - 1512745 - India vs Pakistan
2026-02-15 - international - T20 - female - 1478912 - Australia vs India
2026-02-12 - international - T20 - male - 1512736 - India vs Namibia
2026-02-07 - international - T20 - male - 1512721 - India vs United States of America
2026-01-31 - international - T20 - male - 1490238 - India vs New Zealand
2026-01-28 - international - T20 - male - 1490237 - New Zealand vs India
2026-01-25 - international - T20 - male - 1490236 - New Zealand vs India
2026-01-23 - international - T20 - male - 1490235 - New Zealand vs India
2026-01-21 - international - T20 - male - 1490234 - India vs New Zealand
2026-01-18 - international - ODI - male - 1490233 - New Zealand vs India
2026-01-14 - international - ODI - male - 1490232 - India vs New Zealand
2026-01-11 - international - ODI - male - 1490231 - New Zealand vs India
2025-12-30 - international - T20 - female - 1513739 - India vs Sri Lanka
2025-12-28 - international - T20 - female - 1513738 - India vs Sri Lanka
2025-12-26 - international - T20 - female - 1513737 - Sri Lanka vs India
2025-12-23 - international - T20 - female - 1513736 - Sri Lanka vs India
2025-12-21 - international - T20 - female - 1513735 - Sri Lanka vs India
2025-12-19 - international - T20 - male - 1479580 - India vs South Africa
2025-12-14 - international - T20 - male - 1479578 - South Africa vs India
2025-12-11 - international - T20 - male - 1479577 - South Africa vs India
2025-12-09 - international - T20 - male - 1479576 - India vs South Africa
2025-12-06 - international - ODI - male - 1479575 - South Africa vs India
2025-12-03 - international - ODI - male - 1479574 - India vs South Africa
2025-11-30 - international - ODI - male - 1479573 - India vs South Africa
2025-11-22 - international - Test - male - 1479572 - South Africa vs India
2025-11-14 - international - Test - male - 1479571 - South Africa vs India
2025-11-08 - international - T20 - male - 1478911 - India vs Australia
2025-11-06 - international - T20 - male - 1478910 - India vs Australia
2025-11-02 - international - T20 - male - 1478909 - Australia vs India
2025-11-02 - international - ODI - female - 1490443 - India vs South Africa
2025-10-31 - international - T20 - male - 1478908 - India vs Australia
2025-10-30 - international - ODI - female - 1490442 - Australia vs India
2025-10-29 - international - T20 - male - 1478907 - India vs Australia
2025-10-26 - international - ODI - female - 1490440 - Bangladesh vs India
2025-10-25 - international - ODI - male - 1478906 - Australia vs India
2025-10-23 - international - ODI - male - 1478905 - India vs Australia
2025-10-23 - international - ODI - female - 1490436 - India vs New Zealand
2025-10-19 - international - ODI - male - 1478904 - India vs Australia
2025-10-19 - international - ODI - female - 1490432 - England vs India
2025-10-12 - international - ODI - female - 1490425 - India vs Australia
2025-10-10 - international - Test - male - 1479570 - India vs West Indies
2025-10-09 - international - ODI - female - 1490422 - India vs South Africa
2025-10-05 - international - ODI - female - 1490418 - India vs Pakistan
2025-10-02 - international - Test - male - 1479569 - West Indies vs India
2025-09-30 - international - ODI - female - 1490413 - India vs Sri Lanka
2025-09-28 - international - T20 - male - 1496938 - Pakistan vs India
2025-09-26 - international - T20 - male - 1496937 - India vs Sri Lanka
2025-09-24 - international - T20 - male - 1496935 - India vs Bangladesh
2025-09-21 - international - T20 - male - 1496933 - Pakistan vs India
2025-09-20 - international - ODI - female - 1488250 - Australia vs India
2025-09-19 - international - T20 - male - 1496931 - India vs Oman
2025-09-17 - international - ODI - female - 1488249 - India vs Australia
2025-09-14 - international - T20 - male - 1496925 - Pakistan vs India
2025-09-14 - international - ODI - female - 1488248 - India vs Australia
2025-09-10 - international - T20 - male - 1496921 - United Arab Emirates vs India
2025-07-31 - international - Test - male - 1448353 - India vs England
2025-07-23 - international - Test - male - 1448352 - India vs England
2025-07-22 - international - ODI - female - 1448404 - India vs England
2025-07-19 - international - ODI - female - 1448403 - India vs England
2025-07-16 - international - ODI - female - 1448402 - England vs India
2025-07-12 - international - T20 - female - 1448401 - India vs England
2025-07-10 - international - Test - male - 1448351 - England vs India
2025-07-09 - international - T20 - female - 1448400 - England vs India
2025-07-04 - international - T20 - female - 1448399 - England vs India
2025-07-02 - international - Test - male - 1448350 - India vs England
2025-07-01 - international - T20 - female - 1448398 - India vs England
2025-06-28 - international - T20 - female - 1448397 - India vs England
2025-06-20 - international - Test - male - 1448349 - India vs England
2025-05-11 - international - ODI - female - 1476986 - India vs Sri Lanka
2025-05-07 - international - ODI - female - 1476984 - India vs South Africa
2025-05-04 - international - ODI - female - 1476983 - India vs Sri Lanka
2025-04-29 - international - ODI - female - 1476981 - India vs South Africa
2025-04-27 - international - ODI - female - 1476980 - Sri Lanka vs India
2025-03-09 - international - ODI - male - 1466428 - New Zealand vs India
2025-03-04 - international - ODI - male - 1466426 - Australia vs India
2025-03-02 - international - ODI - male - 1466425 - India vs New Zealand
2025-02-23 - international - ODI - male - 1466418 - Pakistan vs India
2025-02-20 - international - ODI - male - 1466415 - Bangladesh vs India
2025-02-12 - international - ODI - male - 1439906 - India vs England
2025-02-09 - international - ODI - male - 1439905 - England vs India
2025-02-06 - international - ODI - male - 1439904 - England vs India
2025-02-02 - international - T20 - male - 1439903 - India vs England
2025-01-31 - international - T20 - male - 1439902 - India vs England
2025-01-28 - international - T20 - male - 1439901 - England vs India
2025-01-25 - international - T20 - male - 1439900 - England vs India
2025-01-22 - international - T20 - male - 1439899 - England vs India
2025-01-15 - international - ODI - female - 1459899 - India vs Ireland
2025-01-12 - international - ODI - female - 1459898 - India vs Ireland
2025-01-10 - international - ODI - female - 1459897 - Ireland vs India
2025-01-03 - international - Test - male - 1426559 - India vs Australia
2024-12-27 - international - ODI - female - 1459896 - West Indies vs India
2024-12-26 - international - Test - male - 1426558 - Australia vs India
2024-12-24 - international - ODI - female - 1459895 - India vs West Indies
2024-12-22 - international - ODI - female - 1459894 - India vs West Indies
2024-12-19 - international - T20 - female - 1459893 - India vs West Indies
2024-12-17 - international - T20 - female - 1459892 - India vs West Indies
2024-12-15 - international - T20 - female - 1459891 - India vs West Indies
2024-12-14 - international - Test - male - 1426557 - Australia vs India
2024-12-11 - international - ODI - female - 1426622 - Australia vs India
2024-12-08 - international - ODI - female - 1426621 - Australia vs India
2024-12-06 - international - Test - male - 1426556 - India vs Australia
2024-12-05 - international - ODI - female - 1426620 - India vs Australia
2024-11-22 - international - Test - male - 1426555 - India vs Australia
2024-11-15 - international - T20 - male - 1449304 - India vs South Africa
2024-11-13 - international - T20 - male - 1449303 - India vs South Africa
2024-11-10 - international - T20 - male - 1449302 - India vs South Africa
2024-11-08 - international - T20 - male - 1449301 - India vs South Africa
2024-11-01 - international - Test - male - 1439898 - New Zealand vs India
2024-10-29 - international - ODI - female - 1454393 - New Zealand vs India
2024-10-27 - international - ODI - female - 1454392 - New Zealand vs India
2024-10-24 - international - Test - male - 1439897 - New Zealand vs India
2024-10-24 - international - ODI - female - 1454391 - India vs New Zealand
2024-10-16 - international - Test - male - 1439896 - India vs New Zealand
2024-10-13 - international - T20 - female - 1432439 - Australia vs India
2024-10-12 - international - T20 - male - 1439895 - India vs Bangladesh
2024-10-09 - international - T20 - male - 1439894 - India vs Bangladesh
2024-10-09 - international - T20 - female - 1432433 - India vs Sri Lanka
2024-10-06 - international - T20 - male - 1439893 - Bangladesh vs India
2024-10-06 - international - T20 - female - 1432428 - Pakistan vs India
2024-10-04 - international - T20 - female - 1432425 - New Zealand vs India
2024-09-27 - international - Test - male - 1439892 - Bangladesh vs India
2024-09-19 - international - Test - male - 1439891 - India vs Bangladesh
2024-08-07 - international - ODI - male - 1442992 - Sri Lanka vs India
2024-08-04 - international - ODI - male - 1442991 - Sri Lanka vs India
2024-08-02 - international - ODI - male - 1442990 - Sri Lanka vs India
2024-07-30 - international - T20 - male - 1442989 - India vs Sri Lanka
2024-07-28 - international - T20 - male - 1442988 - Sri Lanka vs India
2024-07-28 - international - T20 - female - 1426770 - India vs Sri Lanka
2024-07-27 - international - T20 - male - 1442987 - India vs Sri Lanka
2024-07-26 - international - T20 - female - 1426768 - Bangladesh vs India
2024-07-23 - international - T20 - female - 1426765 - India vs Nepal
2024-07-21 - international - T20 - female - 1426760 - India vs United Arab Emirates
2024-07-19 - international - T20 - female - 1426757 - Pakistan vs India
2024-07-14 - international - T20 - male - 1420227 - India vs Zimbabwe
2024-07-13 - international - T20 - male - 1420226 - Zimbabwe vs India
2024-07-10 - international - T20 - male - 1420225 - India vs Zimbabwe
2024-07-09 - international - T20 - female - 1434293 - South Africa vs India
2024-07-07 - international - T20 - male - 1420224 - India vs Zimbabwe
2024-07-07 - international - T20 - female - 1434292 - South Africa vs India
2024-07-06 - international - T20 - male - 1420223 - Zimbabwe vs India
2024-07-05 - international - T20 - female - 1434291 - South Africa vs India
2024-06-29 - international - T20 - male - 1415755 - India vs South Africa
2024-06-28 - international - Test - female - 1434290 - India vs South Africa
2024-06-27 - international - T20 - male - 1415754 - India vs England
2024-06-24 - international - T20 - male - 1415751 - India vs Australia
2024-06-23 - international - ODI - female - 1434289 - South Africa vs India
2024-06-22 - international - T20 - male - 1415747 - India vs Bangladesh
2024-06-19 - international - ODI - female - 1434288 - India vs South Africa
2024-06-16 - international - ODI - female - 1434287 - India vs South Africa
2024-06-12 - international - T20 - male - 1415725 - United States of America vs India
2024-06-09 - international - T20 - male - 1415719 - India vs Pakistan
2024-06-05 - international - T20 - male - 1415708 - Ireland vs India
2024-05-09 - international - T20 - female - 1429397 - India vs Bangladesh
2024-05-06 - international - T20 - female - 1429396 - India vs Bangladesh
2024-05-02 - international - T20 - female - 1429395 - Bangladesh vs India
2024-04-30 - international - T20 - female - 1429394 - Bangladesh vs India
2024-04-28 - international - T20 - female - 1429393 - India vs Bangladesh
2024-03-07 - international - Test - male - 1389403 - England vs India
2024-02-23 - international - Test - male - 1389402 - England vs India
2024-02-15 - international - Test - male - 1389401 - India vs England
2024-02-02 - international - Test - male - 1389400 - India vs England
2024-01-25 - international - Test - male - 1389399 - England vs India
2024-01-09 - international - T20 - female - 1406083 - India vs Australia
2024-01-07 - international - T20 - female - 1406082 - India vs Australia
2024-01-05 - international - T20 - female - 1406081 - Australia vs India
2024-01-03 - international - Test - male - 1387604 - South Africa vs India
2024-01-02 - international - ODI - female - 1406080 - Australia vs India
2023-12-30 - international - ODI - female - 1406079 - Australia vs India
2023-12-28 - international - ODI - female - 1406078 - India vs Australia
2023-12-26 - international - Test - male - 1387603 - India vs South Africa
2023-12-21 - international - Test - female - 1406077 - Australia vs India
2023-12-21 - international - ODI - male - 1387602 - India vs South Africa
2023-12-19 - international - ODI - male - 1387601 - India vs South Africa
2023-12-17 - international - ODI - male - 1387600 - South Africa vs India
2023-12-14 - international - Test - female - 1406076 - India vs England
2023-12-14 - international - T20 - male - 1387599 - India vs South Africa
2023-12-12 - international - T20 - male - 1387598 - India vs South Africa
2023-12-10 - international - T20 - female - 1406075 - England vs India
2023-12-09 - international - T20 - female - 1406074 - India vs England
2023-12-06 - international - T20 - female - 1406073 - England vs India
2023-12-03 - international - T20 - male - 1389395 - India vs Australia
2023-12-01 - international - T20 - male - 1389394 - India vs Australia
2023-11-28 - international - T20 - male - 1389393 - India vs Australia
2023-11-26 - international - T20 - male - 1389392 - India vs Australia
2023-11-23 - international - T20 - male - 1389391 - Australia vs India
2023-11-19 - international - ODI - male - 1384439 - India vs Australia
2023-11-15 - international - ODI - male - 1384437 - India vs New Zealand
2023-11-12 - international - ODI - male - 1384436 - India vs Netherlands
2023-11-05 - international - ODI - male - 1384428 - India vs South Africa
2023-11-02 - international - ODI - male - 1384424 - India vs Sri Lanka
2023-10-29 - international - ODI - male - 1384420 - India vs England
2023-10-22 - international - ODI - male - 1384412 - New Zealand vs India
2023-10-19 - international - ODI - male - 1384408 - Bangladesh vs India
2023-10-14 - international - ODI - male - 1384403 - Pakistan vs India
2023-10-08 - international - ODI - male - 1384396 - Australia vs India
2023-10-06 - international - T20 - male - 1399117 - Bangladesh vs India
2023-10-03 - international - T20 - male - 1399113 - India vs Nepal
2023-09-27 - international - ODI - male - 1389390 - Australia vs India
2023-09-25 - international - T20 - female - 1399062 - India vs Sri Lanka
2023-09-24 - international - T20 - female - 1399059 - Bangladesh vs India
2023-09-24 - international - ODI - male - 1389389 - India vs Australia
2023-09-22 - international - ODI - male - 1389388 - Australia vs India
2023-09-21 - international - T20 - female - 1399055 - India vs Malaysia
2023-09-17 - international - ODI - male - 1388414 - Sri Lanka vs India
2023-09-15 - international - ODI - male - 1388412 - Bangladesh vs India
2023-09-12 - international - ODI - male - 1388407 - India vs Sri Lanka
2023-09-10 - international - ODI - male - 1388406 - India vs Pakistan
2023-09-04 - international - ODI - male - 1388398 - Nepal vs India
2023-09-02 - international - ODI - male - 1388394 - India vs Pakistan
2023-08-20 - international - T20 - male - 1384637 - India vs Ireland
2023-08-18 - international - T20 - male - 1384634 - Ireland vs India
2023-08-13 - international - T20 - male - 1381221 - India vs West Indies
2023-08-12 - international - T20 - male - 1381220 - West Indies vs India
2023-08-08 - international - T20 - male - 1381219 - West Indies vs India
2023-08-06 - international - T20 - male - 1381218 - India vs West Indies
2023-08-03 - international - T20 - male - 1381217 - West Indies vs India
2023-08-01 - international - ODI - male - 1381216 - India vs West Indies
2023-07-29 - international - ODI - male - 1381215 - India vs West Indies
2023-07-27 - international - ODI - male - 1381214 - West Indies vs India
2023-07-22 - international - ODI - female - 1382168 - Bangladesh vs India
2023-07-20 - international - Test - male - 1381213 - India vs West Indies
2023-07-19 - international - ODI - female - 1382167 - India vs Bangladesh
2023-07-16 - international - ODI - female - 1382166 - Bangladesh vs India
2023-07-13 - international - T20 - female - 1382165 - India vs Bangladesh
2023-07-12 - international - Test - male - 1381212 - West Indies vs India
2023-07-11 - international - T20 - female - 1382164 - India vs Bangladesh
2023-07-09 - international - T20 - female - 1382163 - Bangladesh vs India
2023-06-07 - international - Test - male - 1358412 - Australia vs India
2023-03-22 - international - ODI - male - 1348658 - Australia vs India
2023-03-19 - international - ODI - male - 1348657 - India vs Australia
2023-03-17 - international - ODI - male - 1348656 - Australia vs India
2023-03-09 - international - Test - male - 1348655 - Australia vs India
2023-03-01 - international - Test - male - 1348654 - India vs Australia
2023-02-23 - international - T20 - female - 1338060 - Australia vs India
2023-02-20 - international - T20 - female - 1338057 - India vs Ireland
2023-02-18 - international - T20 - female - 1338053 - England vs India
2023-02-17 - international - Test - male - 1348653 - Australia vs India
2023-02-15 - international - T20 - female - 1338048 - West Indies vs India
2023-02-12 - international - T20 - female - 1338043 - Pakistan vs India
2023-02-09 - international - Test - male - 1348652 - Australia vs India
2023-02-02 - international - T20 - female - 1344517 - India vs South Africa
2023-02-01 - international - T20 - male - 1348651 - India vs New Zealand
2023-01-30 - international - T20 - female - 1344516 - West Indies vs India
2023-01-29 - international - T20 - male - 1348650 - New Zealand vs India
2023-01-28 - international - T20 - female - 1344515 - India vs South Africa
2023-01-27 - international - T20 - male - 1348649 - New Zealand vs India
2023-01-24 - international - ODI - male - 1348648 - India vs New Zealand
2023-01-23 - international - T20 - female - 1344513 - India vs West Indies
2023-01-21 - international - ODI - male - 1348647 - New Zealand vs India
2023-01-19 - international - T20 - female - 1344511 - India vs South Africa
2023-01-18 - international - ODI - male - 1348646 - India vs New Zealand
2023-01-15 - international - ODI - male - 1348645 - India vs Sri Lanka
2023-01-12 - international - ODI - male - 1348644 - Sri Lanka vs India
2023-01-10 - international - ODI - male - 1348643 - India vs Sri Lanka
2023-01-07 - international - T20 - male - 1348642 - India vs Sri Lanka
2023-01-05 - international - T20 - male - 1348641 - Sri Lanka vs India
2023-01-03 - international - T20 - male - 1348640 - India vs Sri Lanka
2022-12-22 - international - Test - male - 1340849 - Bangladesh vs India
2022-12-20 - international - T20 - female - 1345428 - Australia vs India
2022-12-17 - international - T20 - female - 1345427 - Australia vs India
2022-12-14 - international - Test - male - 1340848 - India vs Bangladesh
2022-12-14 - international - T20 - female - 1345426 - Australia vs India
2022-12-11 - international - T20 - female - 1345425 - Australia vs India
2022-12-10 - international - ODI - male - 1340847 - India vs Bangladesh
2022-12-09 - international - T20 - female - 1345424 - India vs Australia
2022-12-07 - international - ODI - male - 1340846 - Bangladesh vs India
2022-12-04 - international - ODI - male - 1340845 - India vs Bangladesh
2022-11-30 - international - ODI - male - 1322280 - India vs New Zealand
2022-11-27 - international - ODI - male - 1322279 - India vs New Zealand
2022-11-25 - international - ODI - male - 1322278 - India vs New Zealand
2022-11-22 - international - T20 - male - 1322277 - New Zealand vs India
2022-11-20 - international - T20 - male - 1322276 - India vs New Zealand
2022-11-10 - international - T20 - male - 1298178 - India vs England
2022-11-06 - international - T20 - male - 1298176 - India vs Zimbabwe
2022-11-02 - international - T20 - male - 1298169 - India vs Bangladesh
2022-10-30 - international - T20 - male - 1298164 - India vs South Africa
2022-10-27 - international - T20 - male - 1298157 - India vs Netherlands
2022-10-23 - international - T20 - male - 1298150 - Pakistan vs India
2022-10-15 - international - T20 - female - 1335808 - Sri Lanka vs India
2022-10-13 - international - T20 - female - 1335806 - India vs Thailand
2022-10-11 - international - ODI - male - 1327511 - South Africa vs India
2022-10-10 - international - T20 - female - 1335803 - Thailand vs India
2022-10-09 - international - ODI - male - 1327510 - South Africa vs India
2022-10-08 - international - T20 - female - 1335799 - India vs Bangladesh
2022-10-07 - international - T20 - female - 1335797 - Pakistan vs India
2022-10-06 - international - ODI - male - 1327509 - South Africa vs India
2022-10-04 - international - T20 - male - 1327508 - South Africa vs India
2022-10-04 - international - T20 - female - 1335792 - India vs United Arab Emirates
2022-10-03 - international - T20 - female - 1335790 - India vs Malaysia
2022-10-02 - international - T20 - male - 1327507 - India vs South Africa
2022-10-01 - international - T20 - female - 1335786 - India vs Sri Lanka
2022-09-28 - international - T20 - male - 1327506 - South Africa vs India
2022-09-25 - international - T20 - male - 1327505 - Australia vs India
2022-09-24 - international - ODI - female - 1301339 - India vs England
2022-09-23 - international - T20 - male - 1327504 - Australia vs India
2022-09-21 - international - ODI - female - 1301338 - India vs England
2022-09-20 - international - T20 - male - 1327503 - India vs Australia
2022-09-18 - international - ODI - female - 1301337 - England vs India
2022-09-15 - international - T20 - female - 1301336 - India vs England
2022-09-13 - international - T20 - female - 1301335 - England vs India
2022-09-10 - international - T20 - female - 1301334 - India vs England
2022-09-06 - international - T20 - male - 1327277 - India vs Sri Lanka
2022-09-04 - international - T20 - male - 1327276 - India vs Pakistan
2022-08-31 - international - T20 - male - 1327272 - India vs Hong Kong
2022-08-28 - international - T20 - male - 1327270 - Pakistan vs India
2022-08-22 - international - ODI - male - 1325551 - India vs Zimbabwe
2022-08-20 - international - ODI - male - 1325550 - Zimbabwe vs India
2022-08-18 - international - ODI - male - 1325549 - Zimbabwe vs India
2022-08-07 - international - T20 - male - 1317907 - India vs West Indies
2022-08-07 - international - T20 - female - 1289274 - Australia vs India
2022-08-06 - international - T20 - male - 1317906 - India vs West Indies
2022-08-06 - international - T20 - female - 1289271 - India vs England
2022-08-03 - international - T20 - female - 1289268 - India vs Barbados
2022-08-02 - international - T20 - male - 1317905 - West Indies vs India
2022-08-01 - international - T20 - male - 1317904 - India vs West Indies
2022-07-31 - international - T20 - female - 1289263 - Pakistan vs India
2022-07-29 - international - T20 - male - 1317903 - India vs West Indies
2022-07-29 - international - T20 - female - 1289259 - India vs Australia
2022-07-27 - international - ODI - male - 1317902 - India vs West Indies
2022-07-24 - international - ODI - male - 1317901 - West Indies vs India
2022-07-22 - international - ODI - male - 1317900 - India vs West Indies
2022-07-17 - international - ODI - male - 1276909 - England vs India
2022-07-14 - international - ODI - male - 1276908 - England vs India
2022-07-12 - international - ODI - male - 1276907 - England vs India
2022-07-10 - international - T20 - male - 1276906 - England vs India
2022-07-09 - international - T20 - male - 1276905 - India vs England
2022-07-07 - international - T20 - male - 1276904 - India vs England
2022-07-07 - international - ODI - female - 1319714 - India vs Sri Lanka
2022-07-04 - international - ODI - female - 1319713 - Sri Lanka vs India
2022-07-01 - international - Test - male - 1320741 - India vs England
2022-07-01 - international - ODI - female - 1319712 - Sri Lanka vs India
2022-06-28 - international - T20 - male - 1303308 - India vs Ireland
2022-06-27 - international - T20 - female - 1319711 - India vs Sri Lanka
2022-06-26 - international - T20 - male - 1303307 - Ireland vs India
2022-06-25 - international - T20 - female - 1319710 - Sri Lanka vs India
2022-06-23 - international - T20 - female - 1319709 - India vs Sri Lanka
2022-06-19 - international - T20 - male - 1278691 - India vs South Africa
2022-06-17 - international - T20 - male - 1278690 - India vs South Africa
2022-06-14 - international - T20 - male - 1278689 - India vs South Africa
2022-06-12 - international - T20 - male - 1278688 - India vs South Africa
2022-06-09 - international - T20 - male - 1278687 - India vs South Africa
2022-03-27 - international - ODI - female - 1243935 - India vs South Africa
2022-03-22 - international - ODI - female - 1243929 - India vs Bangladesh
2022-03-19 - international - ODI - female - 1243925 - India vs Australia
2022-03-16 - international - ODI - female - 1243922 - India vs England
2022-03-12 - international - Test - male - 1278683 - India vs Sri Lanka
2022-03-12 - international - ODI - female - 1243917 - India vs West Indies
2022-03-10 - international - ODI - female - 1243915 - New Zealand vs India
2022-03-06 - international - ODI - female - 1243911 - India vs Pakistan
2022-03-04 - international - Test - male - 1278682 - India vs Sri Lanka
2022-02-27 - international - T20 - male - 1278686 - Sri Lanka vs India
2022-02-26 - international - T20 - male - 1278685 - Sri Lanka vs India
2022-02-24 - international - T20 - male - 1278684 - India vs Sri Lanka
2022-02-24 - international - ODI - female - 1289036 - New Zealand vs India
2022-02-22 - international - ODI - female - 1289035 - New Zealand vs India
2022-02-20 - international - T20 - male - 1278681 - India vs West Indies
2022-02-18 - international - T20 - male - 1278680 - India vs West Indies
2022-02-18 - international - ODI - female - 1289034 - India vs New Zealand
2022-02-16 - international - T20 - male - 1278679 - West Indies vs India
2022-02-15 - international - ODI - female - 1289033 - India vs New Zealand
2022-02-12 - international - ODI - female - 1289032 - New Zealand vs India
2022-02-11 - international - ODI - male - 1278678 - India vs West Indies
2022-02-09 - international - T20 - female - 1289031 - New Zealand vs India
2022-02-09 - international - ODI - male - 1278677 - India vs West Indies
2022-02-06 - international - ODI - male - 1278676 - West Indies vs India
2022-01-23 - international - ODI - male - 1277084 - South Africa vs India
2022-01-21 - international - ODI - male - 1277083 - India vs South Africa
2022-01-19 - international - ODI - male - 1277082 - South Africa vs India
2022-01-11 - international - Test - male - 1277081 - India vs South Africa
2022-01-03 - international - Test - male - 1277080 - India vs South Africa
2021-12-26 - international - Test - male - 1277079 - India vs South Africa
2021-12-03 - international - Test - male - 1278675 - India vs New Zealand
2021-11-25 - international - Test - male - 1278674 - India vs New Zealand
2021-11-21 - international - T20 - male - 1278673 - India vs New Zealand
2021-11-19 - international - T20 - male - 1278672 - New Zealand vs India
2021-11-17 - international - T20 - male - 1278671 - New Zealand vs India
2021-11-08 - international - T20 - male - 1273753 - Namibia vs India
2021-11-05 - international - T20 - male - 1273748 - Scotland vs India
2021-10-31 - international - T20 - male - 1273739 - India vs New Zealand
2021-10-24 - international - T20 - male - 1273727 - India vs Pakistan
2021-10-10 - international - T20 - female - 1263623 - Australia vs India
2021-10-09 - international - T20 - female - 1263622 - India vs Australia
2021-10-07 - international - T20 - female - 1263621 - India vs Australia
2021-09-30 - international - Test - female - 1263620 - India vs Australia
2021-09-26 - international - ODI - female - 1263619 - Australia vs India
2021-09-24 - international - ODI - female - 1263618 - India vs Australia
2021-09-21 - international - ODI - female - 1263617 - India vs Australia
2021-09-02 - international - Test - male - 1239546 - India vs England
2021-08-25 - international - Test - male - 1239545 - India vs England
2021-08-12 - international - Test - male - 1239544 - India vs England
2021-08-04 - international - Test - male - 1239543 - England vs India
2021-07-29 - international - T20 - male - 1262760 - India vs Sri Lanka
2021-07-28 - international - T20 - male - 1262759 - India vs Sri Lanka
2021-07-25 - international - T20 - male - 1262758 - India vs Sri Lanka
2021-07-23 - international - ODI - male - 1262757 - India vs Sri Lanka
2021-07-20 - international - ODI - male - 1262756 - Sri Lanka vs India
2021-07-18 - international - ODI - male - 1262755 - Sri Lanka vs India
2021-07-14 - international - T20 - female - 1260099 - India vs England
2021-07-11 - international - T20 - female - 1260098 - India vs England
2021-07-09 - international - T20 - female - 1260097 - England vs India
2021-07-03 - international - ODI - female - 1260096 - England vs India
2021-06-30 - international - ODI - female - 1260095 - India vs England
2021-06-27 - international - ODI - female - 1260094 - India vs England
2021-06-18 - international - Test - male - 1249875 - India vs New Zealand
2021-06-16 - international - Test - female - 1260093 - England vs India
2021-03-28 - international - ODI - male - 1243395 - India vs England
2021-03-26 - international - ODI - male - 1243394 - India vs England
2021-03-23 - international - T20 - female - 1253274 - South Africa vs India
2021-03-23 - international - ODI - male - 1243393 - India vs England
2021-03-21 - international - T20 - female - 1253273 - India vs South Africa
2021-03-20 - international - T20 - male - 1243392 - India vs England
2021-03-20 - international - T20 - female - 1253272 - India vs South Africa
2021-03-18 - international - T20 - male - 1243391 - India vs England
2021-03-17 - international - ODI - female - 1253271 - India vs South Africa
2021-03-16 - international - T20 - male - 1243390 - India vs England
2021-03-14 - international - T20 - male - 1243389 - England vs India
2021-03-14 - international - ODI - female - 1253270 - India vs South Africa
2021-03-12 - international - T20 - male - 1243388 - India vs England
2021-03-12 - international - ODI - female - 1253269 - India vs South Africa
2021-03-09 - international - ODI - female - 1253268 - South Africa vs India
2021-03-07 - international - ODI - female - 1253267 - India vs South Africa
2021-03-04 - international - Test - male - 1243387 - England vs India
2021-02-24 - international - Test - male - 1243386 - England vs India
2021-02-13 - international - Test - male - 1243385 - India vs England
2021-02-05 - international - Test - male - 1243384 - England vs India
2021-01-15 - international - Test - male - 1223872 - Australia vs India
2021-01-07 - international - Test - male - 1223871 - Australia vs India
2020-12-26 - international - Test - male - 1223870 - Australia vs India
2020-12-17 - international - Test - male - 1223869 - India vs Australia
2020-12-08 - international - T20 - male - 1223954 - Australia vs India
2020-12-06 - international - T20 - male - 1223953 - Australia vs India
2020-12-04 - international - T20 - male - 1223952 - India vs Australia
2020-12-02 - international - ODI - male - 1223957 - India vs Australia
2020-11-29 - international - ODI - male - 1223956 - Australia vs India
2020-11-27 - international - ODI - male - 1223955 - Australia vs India
2020-03-08 - international - T20 - female - 1173070 - Australia vs India
2020-02-29 - international - Test - male - 1187686 - New Zealand vs India
2020-02-29 - international - T20 - female - 1173061 - India vs Sri Lanka
2020-02-27 - international - T20 - female - 1173056 - India vs New Zealand
2020-02-24 - international - T20 - female - 1173053 - Bangladesh vs India
2020-02-21 - international - Test - male - 1187685 - New Zealand vs India
2020-02-21 - international - T20 - female - 1173048 - Australia vs India
2020-02-12 - international - T20 - female - 1183549 - Australia vs India
2020-02-11 - international - ODI - male - 1187684 - New Zealand vs India
2020-02-08 - international - T20 - female - 1183547 - Australia vs India
2020-02-08 - international - ODI - male - 1187683 - New Zealand vs India
2020-02-07 - international - T20 - female - 1183546 - England vs India
2020-02-05 - international - ODI - male - 1187682 - New Zealand vs India
2020-02-02 - international - T20 - male - 1187681 - New Zealand vs India
2020-02-02 - international - T20 - female - 1183545 - Australia vs India
2020-01-31 - international - T20 - male - 1187680 - New Zealand vs India
2020-01-31 - international - T20 - female - 1183543 - England vs India
2020-01-29 - international - T20 - male - 1187679 - New Zealand vs India
2020-01-26 - international - T20 - male - 1187678 - New Zealand vs India
2020-01-24 - international - T20 - male - 1187677 - New Zealand vs India
2020-01-19 - international - ODI - male - 1187029 - India vs Australia
2020-01-17 - international - ODI - male - 1187028 - India vs Australia
2020-01-14 - international - ODI - male - 1187027 - India vs Australia
2020-01-10 - international - T20 - male - 1202244 - India vs Sri Lanka
2020-01-07 - international - T20 - male - 1202243 - India vs Sri Lanka
2019-12-22 - international - ODI - male - 1187023 - India vs West Indies
2019-12-18 - international - ODI - male - 1187022 - India vs West Indies
2019-12-15 - international - ODI - male - 1187021 - India vs West Indies
2019-12-11 - international - T20 - male - 1187020 - India vs West Indies
2019-12-08 - international - T20 - male - 1187019 - India vs West Indies
2019-12-06 - international - T20 - male - 1187018 - India vs West Indies
2019-11-22 - international - Test - male - 1187017 - India vs Bangladesh
2019-11-20 - international - T20 - female - 1202256 - West Indies vs India
2019-11-17 - international - T20 - female - 1202255 - West Indies vs India
2019-11-14 - international - Test - male - 1187016 - India vs Bangladesh
2019-11-14 - international - T20 - female - 1202254 - West Indies vs India
2019-11-10 - international - T20 - male - 1187015 - India vs Bangladesh
2019-11-10 - international - T20 - female - 1202253 - West Indies vs India
2019-11-09 - international - T20 - female - 1202252 - West Indies vs India
2019-11-07 - international - T20 - male - 1187014 - India vs Bangladesh
2019-11-06 - international - ODI - female - 1202251 - West Indies vs India
2019-11-03 - international - T20 - male - 1187013 - India vs Bangladesh
2019-11-03 - international - ODI - female - 1202250 - West Indies vs India
2019-11-01 - international - ODI - female - 1202249 - West Indies vs India
2019-10-19 - international - Test - male - 1187009 - India vs South Africa
2019-10-14 - international - ODI - female - 1200182 - India vs South Africa
2019-10-11 - international - ODI - female - 1200181 - India vs South Africa
2019-10-10 - international - Test - male - 1187008 - India vs South Africa
2019-10-09 - international - ODI - female - 1200180 - India vs South Africa
2019-10-04 - international - T20 - female - 1198482 - India vs South Africa
2019-10-03 - international - T20 - female - 1202366 - India vs South Africa
2019-10-02 - international - Test - male - 1187007 - India vs South Africa
2019-10-01 - international - T20 - female - 1198481 - India vs South Africa
2019-09-24 - international - T20 - female - 1198478 - India vs South Africa
2019-09-22 - international - T20 - male - 1187006 - India vs South Africa
2019-09-18 - international - T20 - male - 1187005 - India vs South Africa
2019-08-30 - international - Test - male - 1188629 - West Indies vs India
2019-08-22 - international - Test - male - 1188628 - West Indies vs India
2019-08-14 - international - ODI - male - 1188626 - West Indies vs India
2019-08-11 - international - ODI - male - 1188625 - West Indies vs India
2019-08-08 - international - ODI - male - 1188624 - West Indies vs India
2019-08-06 - international - T20 - male - 1188623 - West Indies vs India
2019-08-04 - international - T20 - male - 1188622 - India vs West Indies
2019-08-03 - international - T20 - male - 1188621 - India vs West Indies
2019-07-09 - international - ODI - male - 1144528 - India vs New Zealand
2019-07-06 - international - ODI - male - 1144526 - India vs Sri Lanka
2019-07-02 - international - ODI - male - 1144522 - Bangladesh vs India
2019-06-30 - international - ODI - male - 1144520 - England vs India
2019-06-27 - international - ODI - male - 1144516 - India vs West Indies
2019-06-16 - international - ODI - male - 1144504 - India vs Pakistan
2019-06-09 - international - ODI - male - 1144496 - Australia vs India
2019-06-05 - international - ODI - male - 1144490 - India vs South Africa
2019-03-13 - international - ODI - male - 1168246 - India vs Australia
2019-03-10 - international - ODI - male - 1168245 - India vs Australia
2019-03-09 - international - T20 - female - 1172165 - India vs England
2019-03-08 - international - ODI - male - 1168244 - India vs Australia
2019-03-07 - international - T20 - female - 1172164 - India vs England
2019-03-05 - international - ODI - male - 1168243 - India vs Australia
2019-03-04 - international - T20 - female - 1172163 - India vs England
2019-03-02 - international - ODI - male - 1168242 - India vs Australia
2019-02-28 - international - ODI - female - 1172162 - India vs England
2019-02-27 - international - T20 - male - 1168248 - India vs Australia
2019-02-25 - international - ODI - female - 1172161 - India vs England
2019-02-24 - international - T20 - male - 1168247 - India vs Australia
2019-02-22 - international - ODI - female - 1172160 - India vs England
2019-02-10 - international - T20 - male - 1153698 - New Zealand vs India
2019-02-10 - international - T20 - female - 1153860 - New Zealand vs India
2019-02-08 - international - T20 - male - 1153697 - New Zealand vs India
2019-02-08 - international - T20 - female - 1153859 - New Zealand vs India
2019-02-06 - international - T20 - male - 1153696 - New Zealand vs India
2019-02-06 - international - T20 - female - 1153858 - New Zealand vs India
2019-02-03 - international - ODI - male - 1153695 - New Zealand vs India
2019-02-01 - international - ODI - female - 1153857 - New Zealand vs India
2019-01-31 - international - ODI - male - 1153694 - New Zealand vs India
2019-01-29 - international - ODI - female - 1153856 - New Zealand vs India
2019-01-28 - international - ODI - male - 1153693 - New Zealand vs India
2019-01-26 - international - ODI - male - 1153692 - New Zealand vs India
2019-01-24 - international - ODI - female - 1153855 - New Zealand vs India
2019-01-23 - international - ODI - male - 1153691 - New Zealand vs India
2019-01-18 - international - ODI - male - 1144999 - Australia vs India
2019-01-15 - international - ODI - male - 1144998 - Australia vs India
2019-01-12 - international - ODI - male - 1144997 - Australia vs India
2019-01-03 - international - Test - male - 1144996 - Australia vs India
2018-12-26 - international - Test - male - 1144995 - Australia vs India
2018-12-14 - international - Test - male - 1144994 - Australia vs India
2018-12-06 - international - Test - male - 1144993 - India vs Australia
2018-11-25 - international - T20 - male - 1144992 - Australia vs India
2018-11-23 - international - T20 - male - 1144991 - Australia vs India
2018-11-22 - international - T20 - female - 1150554 - India vs England
2018-11-21 - international - T20 - male - 1144990 - Australia vs India
2018-11-17 - international - T20 - female - 1150549 - India vs Australia
2018-11-15 - international - T20 - female - 1150545 - India vs Ireland
2018-11-11 - international - T20 - male - 1157761 - West Indies vs India
2018-11-11 - international - T20 - female - 1150537 - Pakistan vs India
2018-11-09 - international - T20 - female - 1150533 - India vs New Zealand
2018-11-06 - international - T20 - male - 1157760 - India vs West Indies
2018-11-04 - international - T20 - male - 1157759 - West Indies vs India
2018-11-01 - international - ODI - male - 1157758 - West Indies vs India
2018-10-29 - international - ODI - male - 1157757 - India vs West Indies
2018-10-27 - international - ODI - male - 1157756 - West Indies vs India
2018-10-24 - international - ODI - male - 1157755 - India vs West Indies
2018-10-21 - international - ODI - male - 1157754 - West Indies vs India
2018-10-12 - international - Test - male - 1157753 - West Indies vs India
2018-10-04 - international - Test - male - 1157752 - India vs West Indies
2018-09-28 - international - ODI - male - 1153255 - Bangladesh vs India
2018-09-25 - international - T20 - female - 1157713 - India vs Sri Lanka
2018-09-24 - international - T20 - female - 1157712 - Sri Lanka vs India
2018-09-23 - international - ODI - male - 1153251 - Pakistan vs India
2018-09-22 - international - T20 - female - 1157711 - Sri Lanka vs India
2018-09-21 - international - T20 - female - 1157710 - Sri Lanka vs India
2018-09-21 - international - ODI - male - 1153249 - Bangladesh vs India
2018-09-19 - international - ODI - male - 1153247 - Pakistan vs India
2018-09-18 - international - ODI - male - 1153246 - India vs Hong Kong
2018-09-16 - international - ODI - female - 1157708 - India vs Sri Lanka
2018-09-13 - international - ODI - female - 1157707 - India vs Sri Lanka
2018-09-11 - international - ODI - female - 1157706 - Sri Lanka vs India
2018-09-07 - international - Test - male - 1119553 - England vs India
2018-08-30 - international - Test - male - 1119552 - England vs India
2018-08-18 - international - Test - male - 1119551 - India vs England
2018-08-09 - international - Test - male - 1119550 - India vs England
2018-08-01 - international - Test - male - 1119549 - England vs India
2018-07-17 - international - ODI - male - 1119548 - India vs England
2018-07-14 - international - ODI - male - 1119547 - England vs India
2018-07-12 - international - ODI - male - 1119546 - England vs India
2018-07-08 - international - T20 - male - 1119545 - England vs India
2018-07-06 - international - T20 - male - 1119544 - India vs England
2018-07-03 - international - T20 - male - 1119543 - England vs India
2018-06-29 - international - T20 - male - 1140993 - India vs Ireland
2018-06-27 - international - T20 - male - 1140992 - India vs Ireland
2018-06-10 - international - T20 - female - 1148063 - India vs Bangladesh
2018-06-09 - international - T20 - female - 1148060 - Pakistan vs India
2018-06-07 - international - T20 - female - 1148059 - Sri Lanka vs India
2018-06-06 - international - T20 - female - 1148056 - India vs Bangladesh
2018-06-04 - international - T20 - female - 1148052 - India vs Thailand
2018-06-03 - international - T20 - female - 1148048 - India vs Malaysia
2018-04-12 - international - ODI - female - 1131778 - England vs India
2018-04-09 - international - ODI - female - 1131777 - India vs England
2018-03-29 - international - T20 - female - 1131240 - England vs India
2018-03-26 - international - T20 - female - 1131238 - Australia vs India
2018-03-25 - international - T20 - female - 1131237 - India vs England
2018-03-22 - international - T20 - female - 1131235 - India vs Australia
2018-03-18 - international - T20 - male - 1133823 - Bangladesh vs India
2018-03-15 - international - ODI - female - 1131233 - Australia vs India
2018-03-14 - international - T20 - male - 1133821 - India vs Bangladesh
2018-03-12 - international - T20 - male - 1133820 - Sri Lanka vs India
2018-03-12 - international - ODI - female - 1131232 - India vs Australia
2018-03-08 - international - T20 - male - 1133818 - Bangladesh vs India
2018-03-06 - international - T20 - male - 1133817 - India vs Sri Lanka
2018-02-24 - international - T20 - male - 1122287 - India vs South Africa
2018-02-24 - international - T20 - female - 1123210 - India vs South Africa
2018-02-21 - international - T20 - male - 1122286 - India vs South Africa
2018-02-21 - international - T20 - female - 1123209 - South Africa vs India
2018-02-18 - international - T20 - male - 1122285 - India vs South Africa
2018-02-18 - international - T20 - female - 1123208 - India vs South Africa
2018-02-16 - international - T20 - female - 1123207 - South Africa vs India
2018-02-16 - international - ODI - male - 1122284 - South Africa vs India
2018-02-13 - international - T20 - female - 1123206 - South Africa vs India
2018-02-13 - international - ODI - male - 1122283 - India vs South Africa
2018-02-10 - international - ODI - male - 1122282 - India vs South Africa
2018-02-10 - international - ODI - female - 1123205 - India vs South Africa
2018-02-07 - international - ODI - male - 1122281 - India vs South Africa
2018-02-07 - international - ODI - female - 1123204 - India vs South Africa
2018-02-04 - international - ODI - male - 1122280 - South Africa vs India
2018-02-01 - international - ODI - male - 1122279 - South Africa vs India
2018-01-24 - international - Test - male - 1122278 - India vs South Africa
2018-01-13 - international - Test - male - 1122277 - South Africa vs India
2018-01-05 - international - Test - male - 1122276 - South Africa vs India
2017-12-24 - international - T20 - male - 1122731 - Sri Lanka vs India
2017-12-22 - international - T20 - male - 1122730 - India vs Sri Lanka
2017-12-20 - international - T20 - male - 1122729 - India vs Sri Lanka
2017-12-17 - international - ODI - male - 1122728 - Sri Lanka vs India
2017-12-13 - international - ODI - male - 1122727 - India vs Sri Lanka
2017-12-10 - international - ODI - male - 1122726 - India vs Sri Lanka
2017-12-02 - international - Test - male - 1122725 - India vs Sri Lanka
2017-11-24 - international - Test - male - 1122724 - Sri Lanka vs India
2017-11-16 - international - Test - male - 1122723 - India vs Sri Lanka
2017-11-07 - international - T20 - male - 1120095 - India vs New Zealand
2017-11-04 - international - T20 - male - 1120094 - New Zealand vs India
2017-11-01 - international - T20 - male - 1120093 - India vs New Zealand
2017-10-29 - international - ODI - male - 1120092 - India vs New Zealand
2017-10-25 - international - ODI - male - 1120091 - New Zealand vs India
2017-10-22 - international - ODI - male - 1120090 - India vs New Zealand
2017-10-10 - international - T20 - male - 1119502 - India vs Australia
2017-10-07 - international - T20 - male - 1119501 - Australia vs India
2017-10-01 - international - ODI - male - 1119500 - Australia vs India
2017-09-28 - international - ODI - male - 1119499 - Australia vs India
2017-09-24 - international - ODI - male - 1119498 - Australia vs India
2017-09-21 - international - ODI - male - 1119497 - India vs Australia
2017-09-17 - international - ODI - male - 1119496 - India vs Australia
2017-09-06 - international - T20 - male - 1109610 - Sri Lanka vs India
2017-09-03 - international - ODI - male - 1109609 - Sri Lanka vs India
2017-08-31 - international - ODI - male - 1109608 - India vs Sri Lanka
2017-08-27 - international - ODI - male - 1109607 - Sri Lanka vs India
2017-08-24 - international - ODI - male - 1109606 - Sri Lanka vs India
2017-08-20 - international - ODI - male - 1109605 - Sri Lanka vs India
2017-08-12 - international - Test - male - 1109604 - India vs Sri Lanka
2017-08-03 - international - Test - male - 1109603 - India vs Sri Lanka
2017-07-26 - international - Test - male - 1109602 - India vs Sri Lanka
2017-07-23 - international - ODI - female - 1085975 - England vs India
2017-07-20 - international - ODI - female - 1085974 - India vs Australia
2017-07-15 - international - ODI - female - 1085971 - India vs New Zealand
2017-07-12 - international - ODI - female - 1085967 - Australia vs India
2017-07-09 - international - T20 - male - 1098211 - West Indies vs India
2017-07-08 - international - ODI - female - 1085962 - India vs South Africa
2017-07-06 - international - ODI - male - 1098210 - West Indies vs India
2017-07-05 - international - ODI - female - 1085958 - India vs Sri Lanka
2017-07-02 - international - ODI - male - 1098209 - West Indies vs India
2017-07-02 - international - ODI - female - 1085955 - India vs Pakistan
2017-06-30 - international - ODI - male - 1098208 - West Indies vs India
2017-06-29 - international - ODI - female - 1085951 - India vs West Indies
2017-06-25 - international - ODI - male - 1098207 - West Indies vs India
2017-06-24 - international - ODI - female - 1085946 - England vs India
2017-06-23 - international - ODI - male - 1098206 - West Indies vs India
2017-06-18 - international - ODI - male - 1022375 - India vs Pakistan
2017-06-15 - international - ODI - male - 1022373 - Bangladesh vs India
2017-06-11 - international - ODI - male - 1022367 - India vs South Africa
2017-06-08 - international - ODI - male - 1022361 - India vs Sri Lanka
2017-06-04 - international - ODI - male - 1022353 - India vs Pakistan
2017-05-21 - international - ODI - female - 1089533 - South Africa vs India
2017-05-19 - international - ODM - female - 1089531 - India vs Zimbabwe
2017-05-17 - international - ODI - female - 1089528 - South Africa vs India
2017-05-11 - international - ODM - female - 1089525 - India vs Zimbabwe
2017-05-09 - international - ODI - female - 1089522 - South Africa vs India
2017-05-07 - international - ODI - female - 1089521 - India vs Ireland
2017-03-25 - international - Test - male - 1062576 - India vs Australia
2017-03-16 - international - Test - male - 1062575 - India vs Australia
2017-03-04 - international - Test - male - 1062574 - India vs Australia
2017-02-23 - international - Test - male - 1062573 - India vs Australia
2017-02-21 - international - ODI - female - 1073430 - India vs South Africa
2017-02-19 - international - ODI - female - 1073427 - India vs Pakistan
2017-02-17 - international - ODI - female - 1073425 - Bangladesh vs India
2017-02-15 - international - ODI - female - 1073421 - India vs South Africa
2017-02-13 - international - ODM - female - 1073417 - India vs Zimbabwe
2017-02-10 - international - ODI - female - 1073411 - India vs Ireland
2017-02-09 - international - Test - male - 1041761 - India vs Bangladesh
2017-02-08 - international - ODM - female - 1073406 - India vs Thailand
2017-02-07 - international - ODI - female - 1073401 - Sri Lanka vs India
2017-02-01 - international - T20 - male - 1034829 - India vs England
2017-01-29 - international - T20 - male - 1034827 - India vs England
2017-01-26 - international - T20 - male - 1034825 - India vs England
2017-01-22 - international - ODI - male - 1034823 - India vs England
2017-01-19 - international - ODI - male - 1034821 - India vs England
2017-01-15 - international - ODI - male - 1034819 - India vs England
2016-12-16 - international - Test - male - 1034817 - India vs England
2016-12-08 - international - Test - male - 1034815 - India vs England
2016-12-04 - international - T20 - female - 1065348 - India vs Pakistan
2016-11-26 - international - Test - male - 1034813 - India vs England
2016-11-17 - international - Test - male - 1034811 - India vs England
2016-11-09 - international - Test - male - 1034809 - India vs England
2016-10-29 - international - ODI - male - 1030227 - India vs New Zealand
2016-10-26 - international - ODI - male - 1030225 - India vs New Zealand
2016-10-23 - international - ODI - male - 1030223 - India vs New Zealand
2016-10-20 - international - ODI - male - 1030221 - India vs New Zealand
2016-10-16 - international - ODI - male - 1030219 - India vs New Zealand
2016-10-08 - international - Test - male - 1030217 - India vs New Zealand
2016-09-30 - international - Test - male - 1030215 - India vs New Zealand
2016-09-22 - international - Test - male - 1030213 - India vs New Zealand
2016-08-28 - international - T20 - male - 1041617 - India vs West Indies
2016-08-27 - international - T20 - male - 1041615 - India vs West Indies
2016-08-18 - international - Test - male - 1022599 - West Indies vs India
2016-08-09 - international - Test - male - 1022597 - West Indies vs India
2016-07-30 - international - Test - male - 1022595 - West Indies vs India
2016-07-21 - international - Test - male - 1022593 - West Indies vs India
2016-06-22 - international - T20 - male - 1007659 - Zimbabwe vs India
2016-06-20 - international - T20 - male - 1007657 - Zimbabwe vs India
2016-06-18 - international - T20 - male - 1007655 - Zimbabwe vs India
2016-06-15 - international - ODI - male - 1007653 - Zimbabwe vs India
2016-06-13 - international - ODI - male - 1007651 - Zimbabwe vs India
2016-06-11 - international - ODI - male - 1007649 - Zimbabwe vs India
2016-03-31 - international - T20 - male - 951371 - India vs West Indies
2016-03-27 - international - T20 - male - 951363 - India vs Australia
2016-03-27 - international - T20 - female - 951409 - India vs West Indies
2016-03-23 - international - T20 - male - 951353 - India vs Bangladesh
2016-03-22 - international - T20 - female - 951395 - India vs England
2016-03-19 - international - T20 - male - 951341 - India vs Pakistan
2016-03-19 - international - T20 - female - 951387 - India vs Pakistan
2016-03-15 - international - T20 - male - 951329 - India vs New Zealand
2016-03-15 - international - T20 - female - 951375 - India vs Bangladesh
2016-03-06 - international - T20 - male - 966765 - Bangladesh vs India
2016-03-03 - international - T20 - male - 966761 - India vs United Arab Emirates
2016-03-01 - international - T20 - male - 966757 - India vs Sri Lanka
2016-02-27 - international - T20 - male - 966751 - India vs Pakistan
2016-02-24 - international - T20 - male - 966745 - India vs Bangladesh
2016-02-14 - international - T20 - male - 963701 - India vs Sri Lanka
2016-02-12 - international - T20 - male - 963699 - India vs Sri Lanka
2016-02-09 - international - T20 - male - 963697 - India vs Sri Lanka
2016-02-07 - international - ODI - female - 895797 - Australia vs India
2016-01-31 - international - T20 - male - 895821 - Australia vs India
2016-01-31 - international - T20 - female - 895791 - Australia vs India
2016-01-29 - international - T20 - male - 895819 - Australia vs India
2016-01-29 - international - T20 - female - 895789 - Australia vs India
2016-01-26 - international - T20 - male - 895817 - Australia vs India
2016-01-23 - international - ODI - male - 895815 - Australia vs India
2016-01-20 - international - ODI - male - 895813 - Australia vs India
2016-01-17 - international - ODI - male - 895811 - Australia vs India
2016-01-15 - international - ODI - male - 895809 - Australia vs India
2016-01-12 - international - ODI - male - 895807 - Australia vs India
2015-12-03 - international - Test - male - 903609 - India vs South Africa
2015-11-25 - international - Test - male - 903607 - India vs South Africa
2015-11-14 - international - Test - male - 903605 - India vs South Africa
2015-11-05 - international - Test - male - 903603 - India vs South Africa
2015-10-25 - international - ODI - male - 903601 - India vs South Africa
2015-10-22 - international - ODI - male - 903599 - India vs South Africa
2015-10-18 - international - ODI - male - 903597 - India vs South Africa
2015-10-14 - international - ODI - male - 903595 - India vs South Africa
2015-10-11 - international - ODI - male - 903593 - India vs South Africa
2015-10-05 - international - T20 - male - 903589 - India vs South Africa
2015-10-02 - international - T20 - male - 903587 - India vs South Africa
2015-08-28 - international - Test - male - 895777 - Sri Lanka vs India
2015-08-20 - international - Test - male - 895775 - Sri Lanka vs India
2015-08-12 - international - Test - male - 895773 - Sri Lanka vs India
2015-07-19 - international - T20 - male - 885971 - Zimbabwe vs India
2015-07-17 - international - T20 - male - 885969 - Zimbabwe vs India
2015-07-14 - international - ODI - male - 885967 - Zimbabwe vs India
2015-07-12 - international - ODI - male - 885965 - Zimbabwe vs India
2015-07-10 - international - ODI - male - 885959 - Zimbabwe vs India
2015-07-08 - international - ODI - female - 872483 - India vs New Zealand
2015-07-06 - international - ODI - female - 872481 - India vs New Zealand
2015-06-24 - international - ODI - male - 870735 - Bangladesh vs India
2015-06-21 - international - ODI - male - 870733 - Bangladesh vs India
2015-06-18 - international - ODI - male - 870731 - Bangladesh vs India
2015-06-10 - international - Test - male - 870729 - Bangladesh vs India
2015-03-26 - international - ODI - male - 656493 - Australia vs India
2015-03-19 - international - ODI - male - 656485 - Bangladesh vs India
2015-03-14 - international - ODI - male - 656475 - India vs Zimbabwe
2015-03-10 - international - ODI - male - 656465 - India vs Ireland
2015-03-06 - international - ODI - male - 656453 - India vs West Indies
2015-02-28 - international - ODI - male - 656439 - India vs United Arab Emirates
2015-02-22 - international - ODI - male - 656423 - India vs South Africa
2015-02-15 - international - ODI - male - 656405 - India vs Pakistan
2015-01-30 - international - ODI - male - 754759 - England vs India
2015-01-26 - international - ODI - male - 754757 - Australia vs India
2015-01-20 - international - ODI - male - 754753 - England vs India
2015-01-18 - international - ODI - male - 754749 - Australia vs India
2015-01-06 - international - Test - male - 754743 - Australia vs India
2014-12-26 - international - Test - male - 754741 - Australia vs India
2014-12-17 - international - Test - male - 754739 - Australia vs India
2014-12-09 - international - Test - male - 754737 - Australia vs India
2014-11-16 - international - ODI - male - 792297 - India vs Sri Lanka
2014-11-13 - international - ODI - male - 792295 - India vs Sri Lanka
2014-11-09 - international - ODI - male - 792293 - India vs Sri Lanka
2014-11-06 - international - ODI - male - 792291 - India vs Sri Lanka
2014-11-02 - international - ODI - male - 792289 - India vs Sri Lanka
2014-10-17 - international - ODI - male - 770127 - India vs West Indies
2014-10-11 - international - ODI - male - 770123 - India vs West Indies
2014-10-08 - international - ODI - male - 770121 - India vs West Indies
2014-09-07 - international - T20 - male - 667731 - England vs India
2014-09-05 - international - ODI - male - 667729 - England vs India
2014-09-02 - international - ODI - male - 667727 - England vs India
2014-08-30 - international - ODI - male - 667725 - England vs India
2014-08-27 - international - ODI - male - 667723 - England vs India
2014-08-23 - international - ODI - female - 722391 - England vs India
2014-08-21 - international - ODI - female - 722389 - England vs India
2014-08-15 - international - Test - male - 667719 - England vs India
2014-08-13 - international - Test - female - 722387 - England vs India
2014-08-07 - international - Test - male - 667717 - England vs India
2014-07-27 - international - Test - male - 667715 - England vs India
2014-07-17 - international - Test - male - 667713 - England vs India
2014-07-09 - international - Test - male - 667711 - England vs India
2014-06-19 - international - ODI - male - 744683 - Bangladesh vs India
2014-06-17 - international - ODI - male - 744681 - Bangladesh vs India
2014-06-15 - international - ODI - male - 744679 - Bangladesh vs India
2014-04-06 - international - T20 - male - 682965 - India vs Sri Lanka
2014-04-04 - international - T20 - male - 682963 - India vs South Africa
2014-04-02 - international - T20 - female - 683009 - India vs Pakistan
2014-04-01 - international - T20 - female - 683005 - India vs West Indies
2014-03-30 - international - T20 - male - 682951 - Australia vs India
2014-03-30 - international - T20 - female - 682995 - Bangladesh vs India
2014-03-28 - international - T20 - male - 682943 - Bangladesh vs India
2014-03-26 - international - T20 - female - 682981 - England vs India
2014-03-24 - international - T20 - female - 682973 - India vs Sri Lanka
2014-03-23 - international - T20 - male - 682929 - India vs West Indies
2014-03-21 - international - T20 - male - 682921 - India vs Pakistan
2014-03-02 - international - ODI - male - 710301 - India vs Pakistan
2014-02-28 - international - ODI - male - 710297 - India vs Sri Lanka
2014-02-26 - international - ODI - male - 710293 - Bangladesh vs India
2014-02-14 - international - Test - male - 667653 - New Zealand vs India
2014-02-06 - international - Test - male - 667651 - New Zealand vs India
2014-01-31 - international - ODI - male - 667649 - New Zealand vs India
2014-01-28 - international - ODI - male - 667647 - New Zealand vs India
2014-01-25 - international - ODI - male - 667645 - New Zealand vs India
2014-01-22 - international - ODI - male - 667643 - New Zealand vs India
2014-01-19 - international - ODI - male - 667641 - New Zealand vs India
2013-12-26 - international - Test - male - 648667 - South Africa vs India
2013-12-18 - international - Test - male - 648665 - South Africa vs India
2013-12-11 - international - ODI - male - 648655 - South Africa vs India
2013-12-08 - international - ODI - male - 648653 - South Africa vs India
2013-12-05 - international - ODI - male - 648651 - South Africa vs India
2013-11-27 - international - ODI - male - 676533 - India vs West Indies
2013-11-24 - international - ODI - male - 676531 - India vs West Indies
2013-11-21 - international - ODI - male - 676529 - India vs West Indies
2013-11-14 - international - Test - male - 676527 - India vs West Indies
2013-11-06 - international - Test - male - 676525 - India vs West Indies
2013-11-02 - international - ODI - male - 647261 - India vs Australia
2013-10-30 - international - ODI - male - 647259 - India vs Australia
2013-10-23 - international - ODI - male - 647255 - India vs Australia
2013-10-19 - international - ODI - male - 647253 - India vs Australia
2013-10-16 - international - ODI - male - 647251 - India vs Australia
2013-10-13 - international - ODI - male - 647249 - India vs Australia
2013-10-10 - international - T20 - male - 647247 - India vs Australia
2013-08-03 - international - ODI - male - 643677 - Zimbabwe vs India
2013-08-01 - international - ODI - male - 643675 - Zimbabwe vs India
2013-07-28 - international - ODI - male - 643669 - Zimbabwe vs India
2013-07-26 - international - ODI - male - 643667 - Zimbabwe vs India
2013-07-24 - international - ODI - male - 643665 - Zimbabwe vs India
2013-07-11 - international - ODI - male - 597929 - India vs Sri Lanka
2013-07-09 - international - ODI - male - 597928 - India vs Sri Lanka
2013-07-05 - international - ODI - male - 597926 - West Indies vs India
2013-07-02 - international - ODI - male - 597925 - India vs Sri Lanka
2013-06-30 - international - ODI - male - 597924 - West Indies vs India
2013-06-23 - international - ODI - male - 566948 - England vs India
2013-06-20 - international - ODI - male - 566947 - India vs Sri Lanka
2013-06-15 - international - ODI - male - 578623 - India vs Pakistan
2013-06-11 - international - ODI - male - 578619 - India vs West Indies
2013-06-06 - international - ODI - male - 578614 - India vs South Africa
2013-03-22 - international - Test - male - 598815 - India vs Australia
2013-03-14 - international - Test - male - 598814 - India vs Australia
2013-03-02 - international - Test - male - 598813 - India vs Australia
2013-02-22 - international - Test - male - 598812 - India vs Australia
2013-02-05 - international - ODI - female - 594901 - India vs Sri Lanka
2013-02-03 - international - ODI - female - 594897 - India vs England
2013-01-31 - international - ODI - female - 594891 - India vs West Indies
2013-01-27 - international - ODI - male - 565816 - India vs England
2013-01-23 - international - ODI - male - 565815 - India vs England
2013-01-19 - international - ODI - male - 565814 - India vs England
2013-01-15 - international - ODI - male - 565813 - India vs England
2013-01-11 - international - ODI - male - 565812 - India vs England
2013-01-06 - international - ODI - male - 589310 - India vs Pakistan
2013-01-03 - international - ODI - male - 589309 - India vs Pakistan
2012-12-30 - international - ODI - male - 589308 - India vs Pakistan
2012-12-28 - international - T20 - male - 589307 - India vs Pakistan
2012-12-25 - international - T20 - male - 589306 - India vs Pakistan
2012-12-22 - international - T20 - male - 565811 - India vs England
2012-12-20 - international - T20 - male - 565810 - India vs England
2012-12-13 - international - Test - male - 565809 - India vs England
2012-12-05 - international - Test - male - 565808 - India vs England
2012-11-23 - international - Test - male - 565807 - India vs England
2012-11-15 - international - Test - male - 565806 - India vs England
2012-10-31 - international - T20 - female - 584929 - India vs Pakistan
2012-10-28 - international - T20 - female - 584924 - India vs Pakistan
2012-10-03 - international - T20 - female - 584772 - Sri Lanka vs India
2012-10-02 - international - T20 - male - 533295 - India vs South Africa
2012-10-01 - international - T20 - female - 533309 - India vs Pakistan
2012-09-30 - international - T20 - male - 533291 - India vs Pakistan
2012-09-29 - international - T20 - female - 533306 - England vs India
2012-09-28 - international - T20 - male - 533287 - Australia vs India
2012-09-27 - international - T20 - female - 533302 - Australia vs India
2012-09-23 - international - T20 - male - 533281 - England vs India
2012-09-11 - international - T20 - male - 565820 - India vs New Zealand
2012-08-31 - international - Test - male - 565818 - India vs New Zealand
2012-08-23 - international - Test - male - 565817 - India vs New Zealand
2012-08-07 - international - T20 - male - 564786 - Sri Lanka vs India
2012-08-04 - international - ODI - male - 564785 - Sri Lanka vs India
2012-07-31 - international - ODI - male - 564784 - Sri Lanka vs India
2012-07-28 - international - ODI - male - 564783 - Sri Lanka vs India
2012-07-24 - international - ODI - male - 564782 - Sri Lanka vs India
2012-07-21 - international - ODI - male - 564781 - Sri Lanka vs India
2012-07-11 - international - ODI - female - 542856 - England vs India
2012-07-05 - international - ODI - female - 542854 - England vs India
2012-07-04 - international - ODI - female - 542853 - England vs India
2012-07-01 - international - ODI - female - 542852 - England vs India
2012-06-28 - international - T20 - female - 542851 - England vs India
2012-06-26 - international - T20 - female - 542850 - England vs India
2012-03-30 - international - T20 - male - 556252 - South Africa vs India
2012-03-18 - international - ODI - male - 535798 - India vs Pakistan
2012-03-16 - international - ODI - male - 535797 - Bangladesh vs India
2012-03-13 - international - ODI - male - 535795 - India vs Sri Lanka
2012-02-28 - international - ODI - male - 518966 - India vs Sri Lanka
2012-02-26 - international - ODI - male - 518965 - Australia vs India
2012-02-21 - international - ODI - male - 518963 - India vs Sri Lanka
2012-02-19 - international - ODI - male - 518962 - Australia vs India
2012-02-14 - international - ODI - male - 518960 - India vs Sri Lanka
2012-02-12 - international - ODI - male - 518959 - Australia vs India
2012-02-08 - international - ODI - male - 518957 - India vs Sri Lanka
2012-02-05 - international - ODI - male - 518956 - Australia vs India
2012-02-03 - international - T20 - male - 518955 - Australia vs India
2012-02-01 - international - T20 - male - 518954 - Australia vs India
2012-01-24 - international - Test - male - 518953 - Australia vs India
2012-01-13 - international - Test - male - 518952 - Australia vs India
2012-01-03 - international - Test - male - 518951 - Australia vs India
2011-12-26 - international - Test - male - 518950 - Australia vs India
2011-12-11 - international - ODI - male - 536933 - India vs West Indies
2011-12-08 - international - ODI - male - 536932 - India vs West Indies
2011-12-05 - international - ODI - male - 536931 - India vs West Indies
2011-12-02 - international - ODI - male - 536930 - India vs West Indies
2011-11-29 - international - ODI - male - 536929 - India vs West Indies
2011-11-22 - international - Test - male - 535999 - India vs West Indies
2011-11-14 - international - Test - male - 535998 - India vs West Indies
2011-11-06 - international - Test - male - 535997 - India vs West Indies
2011-10-29 - international - T20 - male - 521217 - India vs England
2011-10-25 - international - ODI - male - 521222 - India vs England
2011-10-23 - international - ODI - male - 521221 - India vs England
2011-10-20 - international - ODI - male - 521220 - India vs England
2011-10-17 - international - ODI - male - 521219 - India vs England
2011-10-14 - international - ODI - male - 521218 - India vs England
2011-09-16 - international - ODI - male - 474481 - England vs India
2011-09-11 - international - ODI - male - 474480 - England vs India
2011-09-09 - international - ODI - male - 474479 - England vs India
2011-09-06 - international - ODI - male - 474478 - England vs India
2011-09-03 - international - ODI - male - 474477 - England vs India
2011-08-31 - international - T20 - male - 474476 - England vs India
2011-08-18 - international - Test - male - 474475 - England vs India
2011-08-10 - international - Test - male - 474474 - England vs India
2011-07-29 - international - Test - male - 474473 - England vs India
2011-07-21 - international - Test - male - 474472 - England vs India
2011-07-06 - international - Test - male - 489228 - West Indies vs India
2011-06-28 - international - Test - male - 489227 - West Indies vs India
2011-06-26 - international - T20 - female - 492547 - England vs India
2011-06-20 - international - Test - male - 489226 - West Indies vs India
2011-06-16 - international - ODI - male - 489225 - West Indies vs India
2011-06-13 - international - ODI - male - 489224 - West Indies vs India
2011-06-11 - international - ODI - male - 489223 - West Indies vs India
2011-06-08 - international - ODI - male - 489222 - West Indies vs India
2011-06-06 - international - ODI - male - 489221 - West Indies vs India
2011-06-04 - international - T20 - male - 489220 - West Indies vs India
2011-04-02 - international - ODI - male - 433606 - India vs Sri Lanka
2011-03-30 - international - ODI - male - 433605 - India vs Pakistan
2011-03-24 - international - ODI - male - 433601 - India vs Australia
2011-03-20 - international - ODI - male - 433599 - India vs West Indies
2011-03-12 - international - ODI - male - 433586 - India vs South Africa
2011-03-09 - international - ODI - male - 433582 - India vs Netherlands
2011-03-06 - international - ODI - male - 433578 - India vs Ireland
2011-02-27 - international - ODI - male - 433568 - India vs England
2011-02-19 - international - ODI - male - 433558 - Bangladesh vs India
2011-01-23 - international - ODI - male - 463154 - South Africa vs India
2011-01-21 - international - ODI - male - 463153 - South Africa vs India
2011-01-18 - international - ODI - male - 463152 - South Africa vs India
2011-01-15 - international - ODI - male - 463151 - South Africa vs India
2011-01-12 - international - ODI - male - 463150 - South Africa vs India
2011-01-09 - international - T20 - male - 463149 - South Africa vs India
2011-01-02 - international - Test - male - 463148 - South Africa vs India
2010-12-26 - international - Test - male - 463147 - South Africa vs India
2010-12-16 - international - Test - male - 463146 - South Africa vs India
2010-12-10 - international - ODI - male - 467887 - India vs New Zealand
2010-12-07 - international - ODI - male - 467886 - India vs New Zealand
2010-12-04 - international - ODI - male - 467885 - India vs New Zealand
2010-12-01 - international - ODI - male - 467884 - India vs New Zealand
2010-11-28 - international - ODI - male - 467883 - India vs New Zealand
2010-11-20 - international - Test - male - 464533 - India vs New Zealand
2010-11-12 - international - Test - male - 464532 - India vs New Zealand
2010-11-04 - international - Test - male - 464531 - India vs New Zealand
2010-10-20 - international - ODI - male - 464529 - India vs Australia
2010-10-09 - international - Test - male - 464527 - India vs Australia
2010-10-01 - international - Test - male - 464526 - India vs Australia
2010-08-28 - international - ODI - male - 456668 - Sri Lanka vs India
2010-08-25 - international - ODI - male - 456665 - India vs New Zealand
2010-08-22 - international - ODI - male - 456666 - Sri Lanka vs India
2010-08-16 - international - ODI - male - 456663 - Sri Lanka vs India
2010-08-10 - international - ODI - male - 456662 - India vs New Zealand
2010-08-03 - international - Test - male - 456671 - Sri Lanka vs India
2010-07-26 - international - Test - male - 456670 - Sri Lanka vs India
2010-07-18 - international - Test - male - 456669 - Sri Lanka vs India
2010-06-24 - international - ODI - male - 455237 - Sri Lanka vs India
2010-06-22 - international - ODI - male - 455236 - Sri Lanka vs India
2010-06-19 - international - ODI - male - 455234 - India vs Pakistan
2010-06-16 - international - ODI - male - 455232 - Bangladesh vs India
2010-06-13 - international - T20 - male - 452154 - Zimbabwe vs India
2010-06-12 - international - T20 - male - 452153 - Zimbabwe vs India
2010-06-05 - international - ODI - male - 452150 - India vs Sri Lanka
2010-06-03 - international - ODI - male - 452149 - Zimbabwe vs India
2010-05-30 - international - ODI - male - 452147 - India vs Sri Lanka
2010-05-28 - international - ODI - male - 452146 - Zimbabwe vs India
2010-05-13 - international - T20 - female - 412716 - Australia vs India
2010-05-11 - international - T20 - male - 412699 - India vs Sri Lanka
2010-05-09 - international - T20 - male - 412695 - West Indies vs India
2010-05-07 - international - T20 - male - 412691 - Australia vs India
2010-05-02 - international - T20 - male - 412682 - India vs South Africa
2010-02-27 - international - ODI - male - 441829 - India vs South Africa
2010-02-24 - international - ODI - male - 441828 - India vs South Africa
2010-02-21 - international - ODI - male - 441827 - India vs South Africa
2010-02-14 - international - Test - male - 441826 - India vs South Africa
2010-02-06 - international - Test - male - 441825 - India vs South Africa
2010-01-24 - international - Test - male - 434257 - Bangladesh vs India
2010-01-17 - international - Test - male - 434256 - Bangladesh vs India
2010-01-13 - international - ODI - male - 434264 - India vs Sri Lanka
2010-01-11 - international - ODI - male - 434263 - Bangladesh vs India
2010-01-10 - international - ODI - male - 434262 - India vs Sri Lanka
2010-01-07 - international - ODI - male - 434260 - Bangladesh vs India
2010-01-05 - international - ODI - male - 434259 - India vs Sri Lanka
2009-12-27 - international - ODI - male - 430890 - India vs Sri Lanka
2009-12-24 - international - ODI - male - 430889 - India vs Sri Lanka
2009-12-21 - international - ODI - male - 430888 - India vs Sri Lanka
2009-12-18 - international - ODI - male - 430887 - India vs Sri Lanka
2009-12-15 - international - ODI - male - 430886 - India vs Sri Lanka
2009-12-12 - international - T20 - male - 430885 - India vs Sri Lanka
2009-12-09 - international - T20 - male - 430884 - India vs Sri Lanka
2009-12-02 - international - Test - male - 430883 - India vs Sri Lanka
2009-11-24 - international - Test - male - 430882 - India vs Sri Lanka
2009-11-16 - international - Test - male - 430881 - India vs Sri Lanka
2009-11-08 - international - ODI - male - 416241 - India vs Australia
2009-11-05 - international - ODI - male - 416240 - India vs Australia
2009-11-02 - international - ODI - male - 416239 - India vs Australia
2009-10-31 - international - ODI - male - 416238 - India vs Australia
2009-10-28 - international - ODI - male - 416237 - India vs Australia
2009-10-25 - international - ODI - male - 416236 - India vs Australia
2009-09-30 - international - ODI - male - 415284 - India vs West Indies
2009-09-28 - international - ODI - male - 415281 - Australia vs India
2009-09-26 - international - ODI - male - 415278 - India vs Pakistan
2009-09-14 - international - ODI - male - 403383 - Sri Lanka vs India
2009-09-12 - international - ODI - male - 403381 - Sri Lanka vs India
2009-09-11 - international - ODI - male - 403382 - India vs New Zealand
2009-07-05 - international - ODI - male - 377316 - West Indies vs India
2009-07-03 - international - ODI - male - 377315 - West Indies vs India
2009-06-28 - international - ODI - male - 377314 - West Indies vs India
2009-06-26 - international - ODI - male - 377313 - West Indies vs India
2009-06-18 - international - T20 - female - 355988 - India vs New Zealand
2009-06-16 - international - T20 - male - 356014 - India vs South Africa
2009-06-14 - international - T20 - male - 356010 - England vs India
2009-06-12 - international - T20 - male - 356006 - India vs West Indies
2009-06-10 - international - T20 - male - 356001 - India vs Ireland
2009-06-06 - international - T20 - male - 355994 - Bangladesh vs India
2009-04-03 - international - Test - male - 366629 - New Zealand vs India
2009-03-26 - international - Test - male - 386496 - New Zealand vs India
2009-03-18 - international - Test - male - 366628 - New Zealand vs India
2009-03-14 - international - ODI - male - 366625 - New Zealand vs India
2009-03-11 - international - ODI - male - 366624 - New Zealand vs India
2009-03-10 - international - ODI - female - 357962 - England vs India
2009-03-08 - international - ODI - male - 366627 - New Zealand vs India
2009-03-06 - international - ODI - male - 366626 - New Zealand vs India
2009-03-03 - international - ODI - male - 366623 - New Zealand vs India
2009-02-27 - international - T20 - male - 366622 - New Zealand vs India
2009-02-25 - international - T20 - male - 386494 - New Zealand vs India
2009-02-10 - international - T20 - male - 386535 - Sri Lanka vs India
2009-02-08 - international - ODI - male - 386534 - Sri Lanka vs India
2009-02-05 - international - ODI - male - 386533 - Sri Lanka vs India
2009-02-03 - international - ODI - male - 386532 - Sri Lanka vs India
2009-01-31 - international - ODI - male - 386531 - Sri Lanka vs India
2009-01-28 - international - ODI - male - 386530 - Sri Lanka vs India
2008-12-19 - international - Test - male - 361051 - India vs England
2008-12-11 - international - Test - male - 361050 - India vs England
2008-11-26 - international - ODI - male - 361047 - India vs England
2008-11-23 - international - ODI - male - 361046 - India vs England
2008-11-20 - international - ODI - male - 361045 - India vs England
2008-11-17 - international - ODI - male - 361044 - India vs England
2008-11-14 - international - ODI - male - 361043 - India vs England
2008-11-06 - international - Test - male - 345672 - India vs Australia
2008-10-29 - international - Test - male - 345671 - India vs Australia
2008-10-17 - international - Test - male - 345670 - India vs Australia
2008-10-09 - international - Test - male - 345669 - India vs Australia
2008-08-29 - international - ODI - male - 343736 - Sri Lanka vs India
2008-08-27 - international - ODI - male - 366341 - Sri Lanka vs India
2008-08-24 - international - ODI - male - 343734 - Sri Lanka vs India
2008-08-20 - international - ODI - male - 343733 - Sri Lanka vs India
2008-08-18 - international - ODI - male - 343732 - Sri Lanka vs India
2008-08-08 - international - Test - male - 343731 - Sri Lanka vs India
2008-07-31 - international - Test - male - 343730 - Sri Lanka vs India
2008-07-23 - international - Test - male - 343729 - Sri Lanka vs India
2008-07-06 - international - ODI - male - 335358 - India vs Sri Lanka
2008-07-03 - international - ODI - male - 335356 - India vs Sri Lanka
2008-07-02 - international - ODI - male - 335355 - Pakistan vs India
2008-06-28 - international - ODI - male - 335352 - Bangladesh vs India
2008-06-26 - international - ODI - male - 335351 - Pakistan vs India
2008-06-25 - international - ODI - male - 335349 - Hong Kong vs India
2008-06-14 - international - ODI - male - 345471 - India vs Pakistan
2008-06-12 - international - ODI - male - 345470 - Bangladesh vs India
2008-06-10 - international - ODI - male - 345469 - India vs Pakistan
2008-05-11 - international - ODI - female - 341306 - India vs Sri Lanka
2008-05-08 - international - ODI - female - 341302 - Sri Lanka vs India
2008-04-11 - international - Test - male - 332913 - India vs South Africa
2008-04-03 - international - Test - male - 332912 - India vs South Africa
2008-03-26 - international - Test - male - 332911 - India vs South Africa
2008-03-04 - international - ODI - male - 291372 - Australia vs India
2008-03-02 - international - ODI - male - 291371 - Australia vs India
2008-02-26 - international - ODI - male - 291369 - India vs Sri Lanka
2008-02-24 - international - ODI - male - 291368 - Australia vs India
2008-02-19 - international - ODI - male - 291366 - India vs Sri Lanka
2008-02-17 - international - ODI - male - 291365 - Australia vs India
2008-02-10 - international - ODI - male - 291362 - Australia vs India
2008-02-05 - international - ODI - male - 291360 - India vs Sri Lanka
2008-02-03 - international - ODI - male - 291359 - Australia vs India
2008-02-01 - international - T20 - male - 291356 - Australia vs India
2008-01-24 - international - Test - male - 291354 - Australia vs India
2008-01-16 - international - Test - male - 291353 - Australia vs India
2008-01-02 - international - Test - male - 291352 - Australia vs India
2007-12-26 - international - Test - male - 291351 - Australia vs India
2007-12-08 - international - Test - male - 297808 - India vs Pakistan
2007-11-30 - international - Test - male - 297807 - India vs Pakistan
2007-11-22 - international - Test - male - 297806 - Pakistan vs India
2007-11-18 - international - ODI - male - 297805 - India vs Pakistan
2007-11-15 - international - ODI - male - 297804 - India vs Pakistan
2007-11-11 - international - ODI - male - 297803 - India vs Pakistan
2007-11-08 - international - ODI - male - 297802 - India vs Pakistan
2007-11-05 - international - ODI - male - 297801 - India vs Pakistan
2007-10-20 - international - T20 - male - 297800 - India vs Australia
2007-10-17 - international - ODI - male - 297799 - India vs Australia
2007-10-14 - international - ODI - male - 297798 - India vs Australia
2007-10-11 - international - ODI - male - 297797 - India vs Australia
2007-10-08 - international - ODI - male - 297796 - India vs Australia
2007-10-05 - international - ODI - male - 297795 - India vs Australia
2007-10-02 - international - ODI - male - 297794 - India vs Australia
2007-09-29 - international - ODI - male - 297793 - India vs Australia
2007-09-24 - international - T20 - male - 287879 - India vs Pakistan
2007-09-22 - international - T20 - male - 287878 - Australia vs India
2007-09-20 - international - T20 - male - 287876 - South Africa vs India
2007-09-19 - international - T20 - male - 287873 - England vs India
2007-09-16 - international - T20 - male - 287865 - India vs New Zealand
2007-09-14 - international - T20 - male - 287862 - India vs Pakistan
2007-09-08 - international - ODI - male - 258477 - England vs India
2007-09-05 - international - ODI - male - 258476 - England vs India
2007-09-02 - international - ODI - male - 258475 - England vs India
2007-08-30 - international - ODI - male - 258474 - England vs India
2007-08-27 - international - ODI - male - 258473 - England vs India
2007-08-24 - international - ODI - male - 258472 - England vs India
2007-08-21 - international - ODI - male - 258471 - England vs India
2007-08-16 - international - ODI - male - 275789 - Scotland vs India
2007-08-09 - international - Test - male - 258470 - India vs England
2007-07-27 - international - Test - male - 258469 - England vs India
2007-07-19 - international - Test - male - 258468 - England vs India
2007-07-01 - international - ODI - male - 293078 - India vs South Africa
2007-06-29 - international - ODI - male - 293077 - India vs South Africa
2007-06-26 - international - ODI - male - 293076 - India vs South Africa
2007-06-23 - international - ODI - male - 293071 - Ireland vs India
2007-05-25 - international - Test - male - 282692 - India vs Bangladesh
2007-05-18 - international - Test - male - 282691 - India vs Bangladesh
2007-05-12 - international - ODI - male - 282689 - Bangladesh vs India
2007-05-10 - international - ODI - male - 282688 - Bangladesh vs India
2007-03-23 - international - ODI - male - 247476 - India vs Sri Lanka
2007-03-19 - international - ODI - male - 247468 - Bermuda vs India
2007-03-17 - international - ODI - male - 247464 - Bangladesh vs India
2007-02-17 - international - ODI - male - 267713 - India vs Sri Lanka
2007-02-14 - international - ODI - male - 267715 - India vs Sri Lanka
2007-02-11 - international - ODI - male - 267712 - India vs Sri Lanka
2007-02-08 - international - ODI - male - 267710 - India vs Sri Lanka
2007-01-31 - international - ODI - male - 267709 - India vs West Indies
2007-01-27 - international - ODI - male - 267708 - India vs West Indies
2007-01-02 - international - Test - male - 249217 - India vs South Africa
2006-12-26 - international - Test - male - 249216 - South Africa vs India
2006-12-15 - international - Test - male - 249215 - India vs South Africa
2006-12-03 - international - ODI - male - 249214 - South Africa vs India
2006-12-01 - international - T20 - male - 255954 - South Africa vs India
2006-11-29 - international - ODI - male - 249213 - South Africa vs India
2006-11-26 - international - ODI - male - 249212 - South Africa vs India
2006-11-22 - international - ODI - male - 249211 - South Africa vs India
2006-10-29 - international - ODI - male - 249756 - India vs Australia
2006-10-26 - international - ODI - male - 249753 - India vs West Indies
2006-10-15 - international - ODI - male - 249745 - India vs England
2006-09-22 - international - ODI - male - 256614 - Australia vs India
2006-09-20 - international - ODI - male - 256612 - India vs West Indies
2006-09-16 - international - ODI - male - 256608 - Australia vs India
2006-09-14 - international - ODI - male - 256607 - India vs West Indies
2006-08-18 - international - ODI - male - 256665 - Sri Lanka vs India
2006-08-08 - international - Test - female - 225164 - England vs India
2006-06-30 - international - Test - male - 239923 - India vs West Indies
2006-06-22 - international - Test - male - 239922 - West Indies vs India
2006-06-10 - international - Test - male - 239921 - India vs West Indies
2006-06-02 - international - Test - male - 239920 - India vs West Indies
2006-05-28 - international - ODI - male - 239919 - West Indies vs India
2006-05-26 - international - ODI - male - 239918 - West Indies vs India
2006-05-23 - international - ODI - male - 239917 - West Indies vs India
2006-05-20 - international - ODI - male - 239916 - West Indies vs India
2006-04-19 - international - ODI - male - 244511 - India vs Pakistan
2006-04-18 - international - ODI - male - 244510 - India vs Pakistan
2006-04-15 - international - ODI - male - 238194 - India vs England
2006-04-12 - international - ODI - male - 238193 - India vs England
2006-04-03 - international - ODI - male - 238190 - India vs England
2006-03-31 - international - ODI - male - 238189 - India vs England
2006-03-28 - international - ODI - male - 238188 - India vs England
2006-03-09 - international - Test - male - 238186 - England vs India
2006-03-01 - international - Test - male - 239025 - England vs India
2006-02-19 - international - ODI - male - 237571 - Pakistan vs India
2006-02-16 - international - ODI - male - 237222 - Pakistan vs India
2006-02-13 - international - ODI - male - 236809 - Pakistan vs India
2006-02-11 - international - ODI - male - 236520 - Pakistan vs India
2006-02-06 - international - ODI - male - 235831 - Pakistan vs India
2006-01-29 - international - Test - male - 234783 - Pakistan vs India
2006-01-21 - international - Test - male - 233797 - Pakistan vs India
2005-12-18 - international - Test - male - 226363 - India vs Sri Lanka
2005-11-28 - international - ODI - male - 226359 - South Africa vs India
2005-11-16 - international - ODI - male - 225959 - India vs South Africa
2005-11-12 - international - ODI - male - 225437 - Sri Lanka vs India
2005-11-09 - international - ODI - male - 224556 - Sri Lanka vs India
2005-11-06 - international - ODI - male - 224231 - India vs Sri Lanka
2005-11-03 - international - ODI - male - 223902 - Sri Lanka vs India
2005-10-28 - international - ODI - male - 223334 - Sri Lanka vs India
2005-10-25 - international - ODI - male - 223018 - India vs Sri Lanka
2005-09-13 - international - Test - male - 219062 - Zimbabwe vs India
2005-09-06 - international - ODI - male - 218250 - India vs New Zealand
2005-09-04 - international - ODI - male - 217979 - Zimbabwe vs India
2005-08-29 - international - ODI - male - 217481 - India vs Zimbabwe
2005-07-31 - international - ODI - male - 214742 - West Indies vs India
2005-04-17 - international - ODI - male - 64943 - Pakistan vs India
2005-04-15 - international - ODI - male - 64942 - India vs Pakistan
2005-04-12 - international - ODI - male - 64941 - India vs Pakistan
2005-04-05 - international - ODI - male - 64939 - India vs Pakistan
2004-12-27 - international - ODI - male - 64917 - India vs Bangladesh
2004-12-23 - international - ODI - male - 64914 - India vs Bangladesh
2004-12-10 - international - Test - male - 64111 - Bangladesh vs India
2004-11-28 - international - Test - male - 64110 - South Africa vs India
2004-11-20 - international - Test - male - 64109 - South Africa vs India
2004-11-03 - international - Test - male - 64102 - India vs Australia
2004-10-14 - international - Test - male - 64100 - Australia vs India
2004-09-19 - international - ODI - male - 66207 - India vs Pakistan
2004-09-11 - international - ODI - male - 66198 - India vs Kenya
2004-09-05 - international - ODI - male - 65034 - India vs England
2004-09-03 - international - ODI - male - 65033 - England vs India
2004-09-01 - international - ODI - male - 65032 - India vs England
2004-08-23 - international - ODI - male - 66375 - Australia vs India
2004-08-21 - international - ODI - male - 66374 - Pakistan vs India
2004-08-01 - international - ODI - male - 65718 - Sri Lanka vs India
2004-07-27 - international - ODI - male - 65716 - India vs Sri Lanka
2004-04-13 - international - Test - male - 64083 - Pakistan vs India
2004-03-24 - international - ODI - male - 64885 - India vs Pakistan
2004-03-21 - international - ODI - male - 64884 - Pakistan vs India
2004-03-19 - international - ODI - male - 64883 - India vs Pakistan
2004-03-16 - international - ODI - male - 64882 - Pakistan vs India
2004-02-08 - international - ODI - male - 65656 - Australia vs India
2004-02-06 - international - ODI - male - 65655 - India vs Australia
2004-02-01 - international - ODI - male - 65653 - India vs Australia
2004-01-22 - international - ODI - male - 65649 - India vs Australia
2004-01-20 - international - ODI - male - 65648 - India vs Zimbabwe
2004-01-18 - international - ODI - male - 65647 - India vs Australia
2004-01-14 - international - ODI - male - 65645 - Zimbabwe vs India
2004-01-09 - international - ODI - male - 65643 - Australia vs India
2004-01-02 - international - Test - male - 64062 - India vs Australia
2003-12-04 - international - Test - male - 64059 - Australia vs India
2003-11-15 - international - ODI - male - 66372 - India vs New Zealand
2003-11-06 - international - ODI - male - 66369 - India vs New Zealand
2003-11-01 - international - ODI - male - 66367 - Australia vs India
2003-10-26 - international - ODI - male - 66365 - India vs Australia
2003-10-23 - international - ODI - male - 66364 - India vs New Zealand
2003-10-16 - international - Test - male - 64047 - New Zealand vs India
2003-04-21 - international - ODI - male - 66356 - India vs South Africa
2003-03-23 - international - ODI - male - 65286 - Australia vs India
2003-03-20 - international - ODI - male - 65285 - India vs Kenya
2003-03-14 - international - ODI - male - 65281 - New Zealand vs India
2003-03-10 - international - ODI - male - 65278 - India vs Sri Lanka
2003-03-07 - international - ODI - male - 65276 - Kenya vs India
2003-03-01 - international - ODI - male - 65268 - Pakistan vs India
2003-02-26 - international - ODI - male - 65262 - India vs England
2003-02-23 - international - ODI - male - 65257 - India vs Namibia
2003-02-19 - international - ODI - male - 65250 - India vs Zimbabwe
2003-02-15 - international - ODI - male - 65244 - India vs Australia
2003-02-12 - international - ODI - male - 65241 - India vs Netherlands
2003-01-14 - international - ODI - male - 64819 - India vs New Zealand
2003-01-08 - international - ODI - male - 64817 - New Zealand vs India
2003-01-04 - international - ODI - male - 64816 - India vs New Zealand
2003-01-01 - international - ODI - male - 64815 - India vs New Zealand
2002-12-29 - international - ODI - male - 64814 - New Zealand vs India
2002-06-29 - international - ODI - male - 66284 - England vs India
2001-12-19 - international - Test - male - 63963 - England vs India
